// Vue 앱 마운트는 js/core/app-root.js 에서 처리합니다.
// 이 파일은 향후 확장/부트스트랩 용도로 남겨둔 placeholder 입니다.
